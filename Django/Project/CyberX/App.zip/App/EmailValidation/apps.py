from django.apps import AppConfig


class EmailvalidationConfig(AppConfig):
    name = 'EmailValidation'
