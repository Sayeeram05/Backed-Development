from django.apps import AppConfig


class UrlthreaddetectionConfig(AppConfig):
    name = 'UrlThreadDetection'
