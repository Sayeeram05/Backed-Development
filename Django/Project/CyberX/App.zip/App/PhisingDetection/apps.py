from django.apps import AppConfig


class PhisingdetectionConfig(AppConfig):
    name = 'PhisingDetection'
